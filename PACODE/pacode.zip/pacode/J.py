N = int(input())

if N % 4 == 0:
    print("DERROTA")
else:
    print("VITORIA")